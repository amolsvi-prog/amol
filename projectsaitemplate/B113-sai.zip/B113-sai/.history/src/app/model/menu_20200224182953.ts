export class Menu {

    public static menu:Array<any>=[
        {
            oe:[
                { path: "dashboard",title: "Dashboard",icon: "pe-7s-graph", class: ""},
            ],
            re:[
                { path: "dashboard",title: "Dashboard",icon: "pe-7s-graph", class: ""},
            ],
            bm:[
                { path: "dashboard",title: "Dashboard",icon: "pe-7s-graph", class: ""},
            ],
            ah:[
                { path: "dashboard",title: "Dashboard",icon: "pe-7s-graph", class: ""},
            ],
            cm:[
                { path: "dashboard",title: "Dashboard",icon: "pe-7s-graph", class: ""},
            ]
        }
    ]
}
