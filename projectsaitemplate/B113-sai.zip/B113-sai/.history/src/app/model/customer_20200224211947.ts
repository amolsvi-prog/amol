import { Add } from "./add";

export class Customer {
  id: number;
  name: string;
  address: Add[];
}
