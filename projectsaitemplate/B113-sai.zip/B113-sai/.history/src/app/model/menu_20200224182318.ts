export class Menu {
}
