import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdmindashboarComponent } from '../admindashboar/admindashboar.component';

@NgModule({
  declarations: [AdmindashboarComponent],
  imports: [
    CommonModule
  ]
})
export class AdminModule { }
