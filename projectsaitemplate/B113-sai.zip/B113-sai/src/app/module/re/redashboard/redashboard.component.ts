import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-redashboard',
  templateUrl: './redashboard.component.html',
  styleUrls: ['./redashboard.component.scss']
})
export class RedashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
