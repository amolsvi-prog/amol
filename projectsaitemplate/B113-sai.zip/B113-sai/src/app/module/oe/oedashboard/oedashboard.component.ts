import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oedashboard',
  templateUrl: './oedashboard.component.html',
  styleUrls: ['./oedashboard.component.scss']
})
export class OedashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
