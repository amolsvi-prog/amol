import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ahdashboard',
  templateUrl: './ahdashboard.component.html',
  styleUrls: ['./ahdashboard.component.scss']
})
export class AhdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
