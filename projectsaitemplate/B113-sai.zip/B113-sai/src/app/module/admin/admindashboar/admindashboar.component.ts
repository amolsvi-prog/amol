import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admindashboar',
  templateUrl: './admindashboar.component.html',
  styleUrls: ['./admindashboar.component.scss']
})
export class AdmindashboarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
